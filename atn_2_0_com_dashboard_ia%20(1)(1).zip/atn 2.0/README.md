Flask
flask-mysqldb
Werkzeug