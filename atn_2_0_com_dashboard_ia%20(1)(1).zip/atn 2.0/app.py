import os

from flask import Flask, render_template, request, redirect, session, flash, jsonify
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'atn_sistema_2026'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = os.environ.get('MYSQL_PASSWORD', '262102')
app.config['MYSQL_DB'] = 'atn'

mysql = MySQL(app)

@app.route('/')
def home():
    return render_template('site/index.html')


@app.route('/servicos')
def servicos():
    return render_template('site/servicos.html')


@app.route('/suporte')
def suporte():
    return render_template('site/suporte.html')


@app.route('/contato')
def contato():
    return render_template('site/contato.html')


@app.route('/orcamento', methods=['GET', 'POST'])
def orcamento():

    if request.method == 'POST':

        empresa = request.form['empresa']
        nome = request.form['nome']
        email = request.form['email']
        whatsapp = request.form['whatsapp']
        tipo_servico = request.form['tipo_servico']
        descricao = request.form['descricao']

        cur = mysql.connection.cursor()

        cur.execute("""
            INSERT INTO orcamentos
            (
                empresa,
                nome,
                email,
                whatsapp,
                tipo_servico,
                descricao
            )
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (
            empresa,
            nome,
            email,
            whatsapp,
            tipo_servico,
            descricao
        ))

        mysql.connection.commit()
        cur.close()

        return render_template(
            'site/orcamento.html',
            sucesso=True
        )

    return render_template(
        'site/orcamento.html',
        sucesso=False
    )


@app.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':

        email = request.form['email']
        senha = request.form['senha']

        cur = mysql.connection.cursor()

        cur.execute("""
            SELECT
                id,
                nome,
                senha,
                tipo,
                COALESCE(status, 'ativo')
            FROM usuarios
            WHERE email = %s
        """, (email,))

        usuario = cur.fetchone()

        if usuario and check_password_hash(usuario[2], senha):

            if usuario[4] != 'ativo':
                cur.close()
                return render_template(
                    'auth/login.html',
                    erro='Usuário desativado. Fale com o administrador.'
                )

            session['usuario_id'] = usuario[0]
            session['usuario_nome'] = usuario[1]
            session['usuario_tipo'] = usuario[3]

            cur.execute("""
                UPDATE usuarios
                SET ultimo_login = NOW()
                WHERE id = %s
            """, (usuario[0],))

            mysql.connection.commit()
            cur.close()

            if usuario[3] == 'admin':
                return redirect('/admin')

            return redirect('/painel')

        cur.close()

        return render_template(
            'auth/login.html',
            erro='E-mail ou senha incorretos!'
        )

    return render_template(
        'auth/login.html',
        erro=None
    )


@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():

    if request.method == 'POST':

        nome = request.form['nome']
        empresa = request.form['empresa']
        email = request.form['email']
        senha = request.form['senha']
        confirmar_senha = request.form['confirmar_senha']

        if senha != confirmar_senha:
            return "As senhas não conferem!"

        if len(senha) < 8:
            return "A senha precisa ter no mínimo 8 caracteres."

        cur = mysql.connection.cursor()

        cur.execute("""
            SELECT id
            FROM usuarios
            WHERE email = %s
        """, (email,))

        if cur.fetchone():
            cur.close()
            return "E-mail já cadastrado!"

        senha_hash = generate_password_hash(senha)

        cur.execute("""
            INSERT INTO usuarios
            (
                nome,
                empresa,
                email,
                senha
            )
            VALUES (%s, %s, %s, %s)
        """, (
            nome,
            empresa,
            email,
            senha_hash
        ))

        mysql.connection.commit()
        cur.close()

        return redirect('/login')

    return render_template('auth/cadastro.html')



@app.route('/recuperar-senha', methods=['GET', 'POST'])
def recuperar_senha():

    mensagem = None

    if request.method == 'POST':
        email = request.form['email']

        cur = mysql.connection.cursor()

        cur.execute("""
            SELECT id
            FROM usuarios
            WHERE email = %s
        """, (email,))

        usuario = cur.fetchone()
        cur.close()

        mensagem = 'Se esse e-mail estiver cadastrado, a equipe ATN enviará as instruções de recuperação.'

    return render_template(
        'auth/recuperar_senha.html',
        mensagem=mensagem
    )


@app.route('/logout')
def logout():

    session.clear()

    return redirect('/login')


@app.route('/painel')
def painel():

    if 'usuario_id' not in session:
        return redirect('/login')
    if session.get('usuario_tipo') != 'cliente':
        return redirect('/admin')
    cur = mysql.connection.cursor()

    cur.execute("""
        SELECT
            id,
            titulo,
            categoria,
            status,
            criado_em
        FROM chamados
        WHERE usuario_id = %s
        ORDER BY criado_em DESC
    """, (session['usuario_id'],))

    chamados = cur.fetchall()

    cur.close()

    return render_template(
        'cliente/painel.html',
        chamados=chamados
    )


@app.route('/abrir-chamado', methods=['GET', 'POST'])
def abrir_chamado():

    if 'usuario_id' not in session:
        return redirect('/login')

    if request.method == 'POST':

        titulo = request.form['titulo']
        categoria = request.form['categoria']
        descricao = request.form['descricao']

        cur = mysql.connection.cursor()

        cur.execute("""
            INSERT INTO chamados
            (
                usuario_id,
                titulo,
                categoria,
                descricao
            )
            VALUES (%s, %s, %s, %s)
        """, (
            session['usuario_id'],
            titulo,
            categoria,
            descricao
        ))

        mysql.connection.commit()
        cur.close()

        return redirect('/painel')

    return render_template('cliente/abrir_chamado.html')



@app.route('/cliente/orcamento', methods=['GET', 'POST'])
def cliente_orcamento():

    if 'usuario_id' not in session:
        return redirect('/login')

    cur = mysql.connection.cursor()

    cur.execute("""
        SELECT nome, empresa, email
        FROM usuarios
        WHERE id = %s
    """, (session['usuario_id'],))

    usuario = cur.fetchone()

    if request.method == 'POST':

        empresa = request.form.get('empresa', '')
        nome = request.form['nome']
        email = request.form['email']
        whatsapp = request.form.get('whatsapp', '')
        tipo_servico = request.form['tipo_servico']
        descricao = request.form['descricao']

        cur.execute("""
            INSERT INTO orcamentos
            (
                empresa,
                nome,
                email,
                whatsapp,
                tipo_servico,
                descricao
            )
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (
            empresa,
            nome,
            email,
            whatsapp,
            tipo_servico,
            descricao
        ))

        mysql.connection.commit()
        cur.close()

        flash(
            'Orçamento solicitado com sucesso! Nossa equipe analisará sua solicitação.',
            'sucesso'
        )

        return redirect('/painel')

    cur.close()

    return render_template(
        'cliente/orcamento.html',
        usuario=usuario
    )



def admin_required():
    if 'usuario_id' not in session:
        return redirect('/login')
    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')
    return None


def montar_contexto_ia():
    cur = mysql.connection.cursor()

    cur.execute("SELECT COUNT(*) FROM usuarios WHERE tipo = 'cliente'")
    total_clientes = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM chamados")
    total_chamados = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM chamados WHERE status = 'Aberto'")
    chamados_abertos = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM chamados WHERE status = 'Em andamento'")
    chamados_andamento = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM chamados WHERE status = 'Finalizado'")
    chamados_finalizados = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM orcamentos")
    total_orcamentos = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM orcamentos WHERE status IN ('Novo', 'Em análise')")
    orcamentos_pendentes = cur.fetchone()[0]

    cur.execute("SELECT COALESCE(SUM(valor), 0) FROM financeiro WHERE tipo = 'entrada'")
    entradas = cur.fetchone()[0]

    cur.execute("SELECT COALESCE(SUM(valor), 0) FROM financeiro WHERE tipo = 'saida'")
    saidas = cur.fetchone()[0]

    cur.execute("SELECT COALESCE(SUM(quantidade), 0) FROM estoque")
    itens_estoque = cur.fetchone()[0]

    cur.execute("""
        SELECT categoria, COUNT(*)
        FROM chamados
        GROUP BY categoria
        ORDER BY COUNT(*) DESC
        LIMIT 1
    """)
    categoria_top = cur.fetchone()

    cur.execute("""
        SELECT tipo_servico, COUNT(*)
        FROM orcamentos
        GROUP BY tipo_servico
        ORDER BY COUNT(*) DESC
        LIMIT 1
    """)
    servico_top = cur.fetchone()

    cur.close()

    saldo = entradas - saidas

    return {
        'total_clientes': total_clientes,
        'total_chamados': total_chamados,
        'chamados_abertos': chamados_abertos,
        'chamados_andamento': chamados_andamento,
        'chamados_finalizados': chamados_finalizados,
        'total_orcamentos': total_orcamentos,
        'orcamentos_pendentes': orcamentos_pendentes,
        'entradas': float(entradas),
        'saidas': float(saidas),
        'saldo': float(saldo),
        'itens_estoque': itens_estoque,
        'categoria_top': categoria_top[0] if categoria_top else 'Sem dados',
        'servico_top': servico_top[0] if servico_top else 'Sem dados'
    }


def responder_ia(pergunta):
    pergunta_limpa = (pergunta or '').strip()
    texto = pergunta_limpa.lower()
    contexto = montar_contexto_ia()

    if not pergunta_limpa:
        return 'Digite uma pergunta para que eu possa ajudar.'

    if any(palavra in texto for palavra in ['cliente', 'clientes', 'cadastrado']):
        return f"Atualmente existem {contexto['total_clientes']} clientes cadastrados. Uma boa ação é acompanhar chamados e orçamentos desses clientes para priorizar atendimento comercial."

    if any(palavra in texto for palavra in ['chamado', 'chamados', 'suporte', 'ticket']):
        return f"O sistema possui {contexto['total_chamados']} chamados: {contexto['chamados_abertos']} abertos, {contexto['chamados_andamento']} em andamento e {contexto['chamados_finalizados']} finalizados. A categoria com mais registros é: {contexto['categoria_top']}."

    if any(palavra in texto for palavra in ['orçamento', 'orcamento', 'orçamentos', 'orcamentos', 'proposta']):
        return f"Existem {contexto['total_orcamentos']} orçamentos no sistema, sendo {contexto['orcamentos_pendentes']} ainda pendentes ou em análise. O serviço mais solicitado é: {contexto['servico_top']}."

    if any(palavra in texto for palavra in ['financeiro', 'dinheiro', 'saldo', 'entrada', 'saida', 'saída', 'receita']):
        return f"Resumo financeiro: entradas de R$ {contexto['entradas']:.2f}, saídas de R$ {contexto['saidas']:.2f} e saldo atual de R$ {contexto['saldo']:.2f}."

    if any(palavra in texto for palavra in ['estoque', 'produto', 'produtos', 'item', 'itens']):
        return f"O estoque possui {contexto['itens_estoque']} itens registrados somando todas as quantidades. Recomendo revisar itens com baixa quantidade antes de fechar novos serviços."

    if any(palavra in texto for palavra in ['prioridade', 'priorizar', 'urgente', 'fazer agora', 'recomendação', 'recomendacao']):
        return f"Minha recomendação: priorize os {contexto['chamados_abertos']} chamados abertos e os {contexto['orcamentos_pendentes']} orçamentos pendentes. Isso reduz atraso no suporte e aumenta chance de venda."

    return (
        "Posso te ajudar com clientes, chamados, orçamentos, estoque e financeiro. "
        f"Resumo rápido: {contexto['total_clientes']} clientes, {contexto['chamados_abertos']} chamados abertos, "
        f"{contexto['orcamentos_pendentes']} orçamentos pendentes e saldo financeiro de R$ {contexto['saldo']:.2f}."
    )

@app.route('/admin')
def admin():

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    cur = mysql.connection.cursor()

    cur.execute("""
        SELECT COUNT(*)
        FROM usuarios
        WHERE tipo = 'cliente'
    """)
    total_clientes = cur.fetchone()[0]

    cur.execute("""
        SELECT COUNT(*)
        FROM chamados
    """)
    total_chamados = cur.fetchone()[0]

    cur.execute("""
        SELECT COUNT(*)
        FROM chamados
        WHERE status = 'Aberto'
    """)
    chamados_abertos = cur.fetchone()[0]

    cur.execute("""
        SELECT COUNT(*)
        FROM orcamentos
    """)
    total_orcamentos = cur.fetchone()[0]

    cur.execute("""
        SELECT status, COUNT(*)
        FROM chamados
        GROUP BY status
    """)
    chamados_status = cur.fetchall()

    cur.execute("""
        SELECT tipo_servico, COUNT(*)
        FROM orcamentos
        GROUP BY tipo_servico
        ORDER BY COUNT(*) DESC
        LIMIT 6
    """)
    orcamentos_servico = cur.fetchall()

    cur.execute("""
        SELECT DATE_FORMAT(criado_em, '%d/%m') AS dia, COUNT(*)
        FROM chamados
        WHERE criado_em >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        GROUP BY DATE(criado_em), DATE_FORMAT(criado_em, '%d/%m')
        ORDER BY DATE(criado_em)
    """)
    chamados_por_dia = cur.fetchall()

    cur.execute("""
        SELECT
            chamados.id,
            usuarios.nome,
            chamados.titulo,
            chamados.categoria,
            chamados.status,
            chamados.criado_em
        FROM chamados
        JOIN usuarios
            ON chamados.usuario_id = usuarios.id
        ORDER BY chamados.criado_em DESC
        LIMIT 5
    """)
    chamados_recentes = cur.fetchall()

    cur.execute("""
        SELECT
            id,
            empresa,
            nome,
            tipo_servico,
            status,
            criado_em
        FROM orcamentos
        ORDER BY criado_em DESC
        LIMIT 5
    """)
    orcamentos_recentes = cur.fetchall()

    cur.close()

    return render_template(
        'admin/dashboard.html',
        total_clientes=total_clientes,
        total_chamados=total_chamados,
        chamados_abertos=chamados_abertos,
        total_orcamentos=total_orcamentos,
        chamados_status=chamados_status,
        orcamentos_servico=orcamentos_servico,
        chamados_por_dia=chamados_por_dia,
        chamados_recentes=chamados_recentes,
        orcamentos_recentes=orcamentos_recentes
    )


@app.route('/admin/clientes')
def admin_clientes():

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    cur = mysql.connection.cursor()

    cur.execute("""
        SELECT
            usuarios.id,
            usuarios.nome,
            usuarios.empresa,
            usuarios.email,
            usuarios.tipo,
            usuarios.criado_em,
            COUNT(chamados.id)
        FROM usuarios
        LEFT JOIN chamados
            ON chamados.usuario_id = usuarios.id
        WHERE usuarios.tipo = 'cliente'
        GROUP BY usuarios.id
        ORDER BY usuarios.criado_em DESC
    """)

    clientes = cur.fetchall()

    cur.close()

    return render_template(
        'admin/clientes.html',
        clientes=clientes
    )


@app.route('/admin/chamados')
def admin_chamados():

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    cur = mysql.connection.cursor()

    cur.execute("""
        SELECT
            chamados.id,
            usuarios.nome,
            chamados.titulo,
            chamados.categoria,
            chamados.status,
            chamados.criado_em,
            chamados.descricao,
            chamados.resposta
        FROM chamados
        JOIN usuarios
            ON chamados.usuario_id = usuarios.id
        ORDER BY chamados.criado_em DESC
    """)

    chamados = cur.fetchall()

    cur.close()

    return render_template(
        'admin/chamados.html',
        chamados=chamados
    )


@app.route('/admin/chamado/<int:id>/status', methods=['POST'])
def atualizar_status_chamado(id):

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    status = request.form['status']
    resposta = request.form.get('resposta', '')

    cur = mysql.connection.cursor()

    cur.execute("""
        UPDATE chamados
        SET
            status = %s,
            resposta = %s
        WHERE id = %s
    """, (
        status,
        resposta,
        id
    ))

    mysql.connection.commit()
    cur.close()

    return redirect('/admin/chamados')


@app.route('/admin/chamado/<int:id>/excluir', methods=['POST'])
def excluir_chamado(id):

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    cur = mysql.connection.cursor()

    cur.execute("""
        DELETE FROM chamados
        WHERE id = %s
    """, (id,))

    mysql.connection.commit()
    cur.close()

    return redirect('/admin/chamados')


@app.route('/admin/orcamentos')
def admin_orcamentos():

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    cur = mysql.connection.cursor()

    cur.execute("""
        SELECT
            id,
            empresa,
            nome,
            email,
            whatsapp,
            tipo_servico,
            status,
            criado_em,
            valor,
            prazo,
            observacao
        FROM orcamentos
        ORDER BY criado_em DESC
    """)

    orcamentos = cur.fetchall()

    cur.close()

    return render_template(
        'admin/orcamentos.html',
        orcamentos=orcamentos
    )


@app.route('/admin/orcamento/<int:id>/status', methods=['POST'])
def atualizar_status_orcamento(id):

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    status = request.form.get('status')
    valor = request.form.get('valor')
    prazo = request.form.get('prazo')
    observacao = request.form.get('observacao')

    cur = mysql.connection.cursor()

    if valor is None and prazo is None and observacao is None:
        cur.execute("""
            UPDATE orcamentos
            SET status = %s
            WHERE id = %s
        """, (
            status,
            id
        ))
    else:
        cur.execute("""
            UPDATE orcamentos
            SET
                status = %s,
                valor = %s,
                prazo = %s,
                observacao = %s
            WHERE id = %s
        """, (
            status,
            valor,
            prazo,
            observacao,
            id
        ))

    mysql.connection.commit()
    cur.close()

    return redirect('/admin/orcamentos')



@app.route('/admin/orcamento/<int:id>')
def admin_orcamento_detalhes(id):

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    cur = mysql.connection.cursor()

    cur.execute("""
        SELECT
            id,
            empresa,
            nome,
            email,
            whatsapp,
            tipo_servico,
            status,
            criado_em,
            valor,
            prazo,
            observacao,
            descricao
        FROM orcamentos
        WHERE id = %s
    """, (id,))

    orcamento = cur.fetchone()

    cur.close()

    return render_template(
        'admin/orcamento_detalhes.html',
        orcamento=orcamento
    )

@app.route('/admin/estoque')
def admin_estoque():

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    cur = mysql.connection.cursor()

    cur.execute("""
        SELECT
            id,
            nome,
            categoria,
            quantidade,
            preco
        FROM estoque
        ORDER BY id DESC
    """)

    produtos = cur.fetchall()

    cur.close()

    return render_template(
        'admin/estoque.html',
        produtos=produtos
    )


@app.route('/admin/estoque/adicionar', methods=['POST'])
def adicionar_produto():

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    nome = request.form['nome']
    categoria = request.form['categoria']
    quantidade = request.form['quantidade']
    preco = request.form['preco']

    cur = mysql.connection.cursor()

    cur.execute("""
        INSERT INTO estoque
        (
            nome,
            categoria,
            quantidade,
            preco
        )
        VALUES (%s, %s, %s, %s)
    """, (
        nome,
        categoria,
        quantidade,
        preco
    ))

    mysql.connection.commit()
    cur.close()

    return redirect('/admin/estoque')


@app.route('/admin/estoque/<int:id>/editar', methods=['POST'])
def editar_produto(id):

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    nome = request.form['nome']
    categoria = request.form['categoria']
    quantidade = request.form['quantidade']
    preco = request.form['preco']

    cur = mysql.connection.cursor()

    cur.execute("""
        UPDATE estoque
        SET
            nome = %s,
            categoria = %s,
            quantidade = %s,
            preco = %s
        WHERE id = %s
    """, (
        nome,
        categoria,
        quantidade,
        preco,
        id
    ))

    mysql.connection.commit()
    cur.close()

    return redirect('/admin/estoque')


@app.route('/admin/estoque/<int:id>/excluir', methods=['POST'])
def excluir_produto(id):

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    cur = mysql.connection.cursor()

    cur.execute("""
        DELETE FROM estoque
        WHERE id = %s
    """, (id,))

    mysql.connection.commit()
    cur.close()

    return redirect('/admin/estoque')


@app.route('/admin/usuarios')
def admin_usuarios():

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    cur = mysql.connection.cursor()

    cur.execute("""
        SELECT
            id,
            nome,
            empresa,
            email,
            tipo,
            COALESCE(status, 'ativo'),
            ultimo_login
        FROM usuarios
        ORDER BY id DESC
    """)

    usuarios = cur.fetchall()

    cur.close()

    return render_template(
        'admin/usuarios.html',
        usuarios=usuarios
    )


@app.route('/admin/usuario/<int:id>/atualizar', methods=['POST'])
def atualizar_usuario(id):

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    nome = request.form['nome']
    empresa = request.form.get('empresa', '')
    email = request.form['email']
    tipo = request.form['tipo']
    status = request.form['status']

    cur = mysql.connection.cursor()

    cur.execute("""
        UPDATE usuarios
        SET
            nome = %s,
            empresa = %s,
            email = %s,
            tipo = %s,
            status = %s
        WHERE id = %s
    """, (
        nome,
        empresa,
        email,
        tipo,
        status,
        id
    ))

    mysql.connection.commit()
    cur.close()

    return redirect('/admin/usuarios')





@app.route('/admin/usuario/<int:id>/excluir', methods=['POST'])
def excluir_usuario(id):

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    if session.get('usuario_id') == id:
        return "Você não pode excluir o próprio usuário logado."

    cur = mysql.connection.cursor()

    cur.execute("""
        DELETE FROM usuarios
        WHERE id = %s
    """, (id,))

    mysql.connection.commit()
    cur.close()

    return redirect('/admin/usuarios')



@app.route('/admin/financeiro', methods=['GET', 'POST'])
def admin_financeiro():

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    cur = mysql.connection.cursor()

    if request.method == 'POST':

        tipo = request.form['tipo']
        descricao = request.form['descricao']
        valor = request.form['valor']

        cur.execute("""
            INSERT INTO financeiro
            (
                tipo,
                descricao,
                valor
            )
            VALUES (%s, %s, %s)
        """, (
            tipo,
            descricao,
            valor
        ))

        mysql.connection.commit()

        flash(
            'Lançamento financeiro cadastrado com sucesso!',
            'sucesso'
        )

    cur.execute("""
        SELECT
            id,
            tipo,
            descricao,
            valor,
            criado_em
        FROM financeiro
        ORDER BY criado_em DESC
    """)

    movimentacoes = cur.fetchall()

    cur.execute("""
        SELECT COALESCE(SUM(valor),0)
        FROM financeiro
        WHERE tipo = 'entrada'
    """)
    entradas = cur.fetchone()[0]

    cur.execute("""
        SELECT COALESCE(SUM(valor),0)
        FROM financeiro
        WHERE tipo = 'saida'
    """)
    saidas = cur.fetchone()[0]

    saldo = entradas - saidas

    cur.close()

    return render_template(
        'admin/financeiro.html',
        movimentacoes=movimentacoes,
        entradas=entradas,
        saidas=saidas,
        saldo=saldo
    )


@app.route('/admin/financeiro/<int:id>/editar', methods=['POST'])
def editar_financeiro(id):

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    tipo = request.form['tipo']
    descricao = request.form['descricao']
    valor = request.form['valor']

    cur = mysql.connection.cursor()

    cur.execute("""
        UPDATE financeiro
        SET
            tipo = %s,
            descricao = %s,
            valor = %s
        WHERE id = %s
    """, (
        tipo,
        descricao,
        valor,
        id
    ))

    mysql.connection.commit()

    flash(
        'Movimentação atualizada com sucesso!',
        'info'
    )

    cur.close()

    return redirect('/admin/financeiro')


@app.route('/admin/financeiro/<int:id>/excluir', methods=['POST'])
def excluir_financeiro(id):

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    cur = mysql.connection.cursor()

    cur.execute("""
        DELETE FROM financeiro
        WHERE id = %s
    """, (id,))

    mysql.connection.commit()

    flash(
        'Movimentação excluída com sucesso!',
        'erro'
    )

    cur.close()

    return redirect('/admin/financeiro')


@app.route('/admin/dashboard-ia')
def admin_dashboard_ia():

    bloqueio = admin_required()
    if bloqueio:
        return bloqueio

    cur = mysql.connection.cursor()

    cur.execute("SELECT COUNT(*) FROM usuarios WHERE tipo = 'cliente'")
    total_clientes = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM chamados")
    total_chamados = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM chamados WHERE status = 'Aberto'")
    chamados_abertos = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM orcamentos")
    total_orcamentos = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM orcamentos WHERE status IN ('Novo', 'Em análise')")
    orcamentos_pendentes = cur.fetchone()[0]

    cur.execute("SELECT COALESCE(SUM(valor),0) FROM financeiro WHERE tipo = 'entrada'")
    entradas = cur.fetchone()[0]

    cur.execute("SELECT COALESCE(SUM(valor),0) FROM financeiro WHERE tipo = 'saida'")
    saidas = cur.fetchone()[0]

    cur.execute("""
        SELECT status, COUNT(*)
        FROM chamados
        GROUP BY status
        ORDER BY COUNT(*) DESC
    """)
    chamados_status = cur.fetchall()

    cur.execute("""
        SELECT status, COUNT(*)
        FROM orcamentos
        GROUP BY status
        ORDER BY COUNT(*) DESC
    """)
    orcamentos_status = cur.fetchall()

    cur.execute("""
        SELECT tipo_servico, COUNT(*)
        FROM orcamentos
        GROUP BY tipo_servico
        ORDER BY COUNT(*) DESC
        LIMIT 8
    """)
    servicos_mais_pedidos = cur.fetchall()

    cur.execute("""
        SELECT DATE_FORMAT(criado_em, '%d/%m') AS dia, COUNT(*)
        FROM orcamentos
        WHERE criado_em >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)
        GROUP BY DATE(criado_em), DATE_FORMAT(criado_em, '%d/%m')
        ORDER BY DATE(criado_em)
    """)
    orcamentos_por_dia = cur.fetchall()

    cur.execute("""
        SELECT DATE_FORMAT(criado_em, '%d/%m') AS dia, COUNT(*)
        FROM chamados
        WHERE criado_em >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)
        GROUP BY DATE(criado_em), DATE_FORMAT(criado_em, '%d/%m')
        ORDER BY DATE(criado_em)
    """)
    chamados_por_dia = cur.fetchall()

    cur.close()

    saldo = entradas - saidas
    taxa_pendencia = 0
    if total_orcamentos:
        taxa_pendencia = round((orcamentos_pendentes / total_orcamentos) * 100, 1)

    return render_template(
        'admin/dashboard_ia.html',
        total_clientes=total_clientes,
        total_chamados=total_chamados,
        chamados_abertos=chamados_abertos,
        total_orcamentos=total_orcamentos,
        orcamentos_pendentes=orcamentos_pendentes,
        entradas=entradas,
        saidas=saidas,
        saldo=saldo,
        taxa_pendencia=taxa_pendencia,
        chamados_status=chamados_status,
        orcamentos_status=orcamentos_status,
        servicos_mais_pedidos=servicos_mais_pedidos,
        orcamentos_por_dia=orcamentos_por_dia,
        chamados_por_dia=chamados_por_dia
    )


@app.route('/admin/ia')
def admin_ia():

    bloqueio = admin_required()
    if bloqueio:
        return bloqueio

    contexto = montar_contexto_ia()

    return render_template(
        'admin/ia.html',
        contexto=contexto
    )


@app.route('/admin/ia/perguntar', methods=['POST'])
def admin_ia_perguntar():

    if 'usuario_id' not in session or session.get('usuario_tipo') != 'admin':
        return jsonify({'resposta': 'Acesso negado. Faça login como administrador.'}), 403

    dados = request.get_json(silent=True) or {}
    pergunta = dados.get('pergunta', '')
    resposta = responder_ia(pergunta)

    return jsonify({'resposta': resposta})


@app.route('/admin/configuracoes', methods=['GET', 'POST'])
def admin_configuracoes():

    if 'usuario_id' not in session:
        return redirect('/login')

    if session.get('usuario_tipo') != 'admin':
        return redirect('/painel')

    mensagem = None

    if request.method == 'POST':
        mensagem = 'Configurações salvas com sucesso.'

    return render_template(
        'admin/configuracoes.html',
        mensagem=mensagem
    )


@app.route('/painel/orcamentos', methods=['GET', 'POST'])
def cliente_orcamentos():

    if 'usuario_id' not in session:
        return redirect('/login')

    if request.method == 'POST':

        empresa = request.form.get('empresa', '')
        nome = session.get('usuario_nome', request.form.get('nome', 'Cliente'))
        email = request.form.get('email', '')
        whatsapp = request.form.get('whatsapp', '')
        tipo_servico = request.form.get('tipo_servico', '')
        descricao = request.form.get('descricao', '')

        cur = mysql.connection.cursor()

        cur.execute("""
            INSERT INTO orcamentos
            (
                empresa,
                nome,
                email,
                whatsapp,
                tipo_servico,
                descricao
            )
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (
            empresa,
            nome,
            email,
            whatsapp,
            tipo_servico,
            descricao
        ))

        mysql.connection.commit()
        cur.close()

        flash(
            'Orçamento solicitado com sucesso!',
            'sucesso'
        )

        return redirect('/painel/orcamentos')

    return render_template(
        'cliente/orcamento.html',
        sucesso=False
    )


if __name__ == '__main__':
    app.run(debug=True)